/*
 * version.h 
 * Automatically generated
 */
#define DAHDI_VERSION "3.2.0"


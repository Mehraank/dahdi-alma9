#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x8d098dd4, "seq_release" },
	{ 0x42cd7ed2, "seq_lseek" },
	{ 0xa35a9cc0, "seq_read" },
	{ 0x83ba136e, "remove_proc_entry" },
	{ 0xb66b52b, "dahdi_dynamic_unregister_driver" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0xb5e84b77, "dev_remove_pack" },
	{ 0xcd3c7696, "del_timer_sync" },
	{ 0xaa101e4c, "proc_create_data" },
	{ 0x160f1369, "dahdi_dynamic_register_driver" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0x3f42594a, "dev_add_pack" },
	{ 0x78534f62, "init_timer_key" },
	{ 0xb066c88a, "skb_queue_tail" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x38aa1380, "skb_push" },
	{ 0xfb578fc5, "memset" },
	{ 0xd09827c9, "skb_put" },
	{ 0xb048d907, "__netdev_alloc_skb" },
	{ 0x69acdf38, "memcpy" },
	{ 0x7c8af009, "__pskb_pull_tail" },
	{ 0xe0272619, "kfree_skb_reason" },
	{ 0x95f4b173, "dahdi_dynamic_receive" },
	{ 0x9fbff1b3, "skb_pull" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x6091797f, "synchronize_rcu" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x37a0cba, "kfree" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xa916b694, "strnlen" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0xe6586838, "dev_get_by_name" },
	{ 0x28bbb0e9, "init_net" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0x754d539c, "strlen" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0x92997ed8, "_printk" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x882ee7f1, "skb_dequeue" },
	{ 0x9e189b07, "dev_queue_xmit" },
	{ 0x2469810f, "__rcu_read_unlock" },
	{ 0xf5f7945b, "seq_printf" },
	{ 0x8d522714, "__rcu_read_lock" },
	{ 0x33267c2e, "single_open" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x5b8239ca, "__x86_return_thunk" },
};

MODULE_INFO(depends, "dahdi_dynamic");


MODULE_INFO(srcversion, "8F6DF5FD648D467A4B721ED");
MODULE_INFO(rhelversion, "9.2");

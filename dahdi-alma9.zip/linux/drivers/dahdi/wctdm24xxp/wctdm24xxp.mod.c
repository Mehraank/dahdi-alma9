#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x98da17ec, "vpmoct_preecho_enable" },
	{ 0x635a1d83, "gpakConfigurePorts" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x65b711df, "_dahdi_transmit" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0x6b0e4a44, "vpmadt032_free" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x7dc85898, "dahdi_free_device" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x293574bc, "vpmadt032_alloc" },
	{ 0x6ee3e77, "dahdi_alarm_channel" },
	{ 0xe8a9b8fa, "gpakConfigureChannel" },
	{ 0xf4dd4fe6, "vpmoct_init" },
	{ 0x6bd0e573, "down_interruptible" },
	{ 0xc615a5f, "dahdi_hdlc_finish" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0xf926337c, "__voicebus_init" },
	{ 0x7f03b6a9, "crc_ccitt_table" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x4cfe37ba, "__dahdi_ec_chunk" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xfae93789, "vpmadt032_echocan_free" },
	{ 0xad2ea79a, "_dev_notice" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x6da3e33, "voicebus_set_minlatency" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xfb384d37, "kasprintf" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x25974000, "wait_for_completion" },
	{ 0x34163751, "param_ops_charp" },
	{ 0xf9c0b663, "strlcat" },
	{ 0x8019389a, "gpakAlgControl" },
	{ 0x97d65876, "_dev_warn" },
	{ 0x9ec7df0f, "vpmadt032_init" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xcb6a6471, "current_task" },
	{ 0x4a3f84c3, "dahdi_hdlc_abort" },
	{ 0x1a58e9f7, "dahdi_register_device" },
	{ 0xe9ffc063, "down_trylock" },
	{ 0x922ce8ff, "vpmadt032_test" },
	{ 0x6460d9de, "dahdi_unregister_device" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x349417e, "voicebus_release" },
	{ 0x2e3bcce2, "wait_for_completion_interruptible" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0x423de3a7, "vpmoct_free" },
	{ 0x102cf10b, "vpmadt032_get_default_parameters" },
	{ 0x3c9cd967, "dahdi_hooksig" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x3dcc0ee2, "dahdi_qevent_lock" },
	{ 0x6626afca, "down" },
	{ 0x3917833f, "dahdi_create_device" },
	{ 0x2f7754a8, "dma_pool_free" },
	{ 0xc15e07ba, "voicebus_start" },
	{ 0x32a096d4, "_dev_err" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x43f5d304, "_dahdi_receive" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0xa5a5f7b2, "vpmoct_alloc" },
	{ 0x79d9fc01, "_dev_info" },
	{ 0xe5eb1132, "gpakPingDsp" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x1000e51, "schedule" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x678b96ec, "dma_pool_alloc" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x43e4e938, "pci_unregister_driver" },
	{ 0xcc5005fe, "msleep_interruptible" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x792ff8c3, "__dynamic_dev_dbg" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0x37a0cba, "kfree" },
	{ 0xaf8dd878, "voicebus_stop" },
	{ 0x7c836b31, "dahdi_hdlc_getbuf" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0xcf2a6966, "up" },
	{ 0xfecf45d9, "vpmoct_echocan_create" },
	{ 0x1a16c6ec, "__pci_register_driver" },
	{ 0x80f91d88, "vpmadt032_echocan_create" },
	{ 0x64773b08, "request_firmware" },
	{ 0x59a682be, "dahdi_alarm_notify" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0xa6257a2f, "complete" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x311b6d99, "vpmoct_echocan_free" },
	{ 0xb507d57f, "voicebus_current_latency" },
	{ 0xdb386b5, "dahdi_hdlc_putbuf" },
	{ 0x4dd8ebc9, "voicebus_quiesce" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x16f56967, "param_ops_uint" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0xe46d18c5, "vpmoct_preecho_disable" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0x1bde64fb, "voicebus_transmit" },
};

MODULE_INFO(depends, "dahdi_voicebus,dahdi");

MODULE_ALIAS("pci:v0000D161d00002400sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008003sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008007sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008008sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "8DC54AA48A882B87E330604");
MODULE_INFO(rhelversion, "9.2");

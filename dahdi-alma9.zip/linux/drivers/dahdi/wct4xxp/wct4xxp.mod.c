#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0xf8a56864, "Oct6100ChannelOpen" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x6ea97ba9, "Oct6100ToneDetectionEnableDef" },
	{ 0x8a9fa9df, "device_remove_file" },
	{ 0x65b711df, "_dahdi_transmit" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0xf9a482f9, "msleep" },
	{ 0x9af5c851, "dahdi_rbsbits" },
	{ 0xef4b16bf, "Oct6100ChipOpen" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x7dc85898, "dahdi_free_device" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0xc07351b3, "__SCT__cond_resched" },
	{ 0x20728ec0, "Oct6100ChannelOpenDef" },
	{ 0xe59837f0, "Oct6100ChipClose" },
	{ 0xc615a5f, "dahdi_hdlc_finish" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x6eefa3a6, "Oct6100ChipCloseDef" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x6c565caa, "pci_release_regions" },
	{ 0x4cfe37ba, "__dahdi_ec_chunk" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x999e8297, "vfree" },
	{ 0x1246105b, "dma_free_attrs" },
	{ 0xad2ea79a, "_dev_notice" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x7f3521aa, "Oct6100GetInstanceSize" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x34163751, "param_ops_charp" },
	{ 0x13edb133, "pci_set_master" },
	{ 0x8887613e, "Oct6100ChannelModifyDef" },
	{ 0x97d65876, "_dev_warn" },
	{ 0xfb578fc5, "memset" },
	{ 0x4016fe37, "pci_restore_state" },
	{ 0xf200ff65, "pci_iounmap" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x4a3f84c3, "dahdi_hdlc_abort" },
	{ 0x1a58e9f7, "dahdi_register_device" },
	{ 0x4c29be43, "dahdi_spantype2str" },
	{ 0x6460d9de, "dahdi_unregister_device" },
	{ 0x7e4d5b85, "dahdi_init_span" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0x33729020, "Oct6100InterruptServiceRoutine" },
	{ 0x8bcefb0d, "Oct6100GetInstanceSizeDef" },
	{ 0x2d4d420f, "Oct6100ChipOpenDef" },
	{ 0x5df1f3bd, "dma_alloc_attrs" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x3fde93a5, "Oct6100InterruptServiceRoutineDef" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x3dcc0ee2, "dahdi_qevent_lock" },
	{ 0x3917833f, "dahdi_create_device" },
	{ 0xc054a762, "Oct6100ApiGetCapacityPins" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x32a096d4, "_dev_err" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x43f5d304, "_dahdi_receive" },
	{ 0x9404793, "Oct6100ToneDetectionEnable" },
	{ 0x1c9f88fd, "device_create_file" },
	{ 0x79d9fc01, "_dev_info" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x73382716, "Oct6100EventGetToneDef" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x43e4e938, "pci_unregister_driver" },
	{ 0xa498779d, "Oct6100ChannelModify" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x792ff8c3, "__dynamic_dev_dbg" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x37a0cba, "kfree" },
	{ 0x126f8326, "pci_request_regions" },
	{ 0x238df932, "Oct6100EventGetTone" },
	{ 0x7c836b31, "dahdi_hdlc_getbuf" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x2c20e37d, "Oct6100ApiGetCapacityPinsDef" },
	{ 0x1a16c6ec, "__pci_register_driver" },
	{ 0x64773b08, "request_firmware" },
	{ 0x59a682be, "dahdi_alarm_notify" },
	{ 0x71afbda5, "_dahdi_ec_span" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x9a5ca076, "pci_iomap" },
	{ 0x7f02188f, "__msecs_to_jiffies" },
	{ 0xdb386b5, "dahdi_hdlc_putbuf" },
	{ 0xffd0ea69, "pci_enable_device" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0xc1514a3b, "free_irq" },
	{ 0x1a5cec42, "pci_save_state" },
};

MODULE_INFO(depends, "oct612x,dahdi");

MODULE_ALIAS("pci:v000010EEd00000314sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001820sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001420sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001410sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001405sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000420sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000410sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000405sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000410sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000405sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000410sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000405sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001220sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001205sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00001210sv00000005sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000220sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000205sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000210sv00000004sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000205sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000210sv00000003sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000205sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00000210sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "4DCB2709E79E66249BB4325");
MODULE_INFO(rhelversion, "9.2");

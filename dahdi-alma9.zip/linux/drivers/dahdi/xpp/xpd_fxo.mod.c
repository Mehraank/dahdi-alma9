#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x8a9fa9df, "device_remove_file" },
	{ 0xf9a482f9, "msleep" },
	{ 0xb64274b3, "xpd_driver_register" },
	{ 0xe3d99689, "xproto_unregister" },
	{ 0x33267c2e, "single_open" },
	{ 0x64fc0feb, "notify_rxsig" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x67715423, "generic_card_pcm_recompute" },
	{ 0x6ee3e77, "dahdi_alarm_channel" },
	{ 0xdf0256ec, "single_release" },
	{ 0x949b7a33, "report_bad_ioctl" },
	{ 0xf5f7945b, "seq_printf" },
	{ 0x83ba136e, "remove_proc_entry" },
	{ 0x62878f47, "param_ops_bool" },
	{ 0x5811f96d, "notify_bad_xpd" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xa35a9cc0, "seq_read" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xbdc15b2d, "oht_pcm" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xa47597fb, "mark_offhook" },
	{ 0xd4a2e742, "xproto_card_entry" },
	{ 0xc37c7a0a, "xproto_register" },
	{ 0x3dcc0ee2, "dahdi_qevent_lock" },
	{ 0x1c9f88fd, "device_create_file" },
	{ 0x14547b49, "xpd_free" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xd2651e59, "generic_card_pcm_fromspan" },
	{ 0xc9eb245, "generic_card_pcm_tospan" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x541a4266, "generic_echocancel_timeslot" },
	{ 0xaa101e4c, "proc_create_data" },
	{ 0x3c9d08ea, "generic_timing_priority" },
	{ 0x42cd7ed2, "seq_lseek" },
	{ 0x5034165d, "xpd_alloc" },
	{ 0x60d56d3d, "generic_echocancel_setmask" },
	{ 0x71c1e75e, "hookstate_changed" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xda23ed38, "xpp_register_request" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x16f56967, "param_ops_uint" },
	{ 0x77634e4b, "xpd_driver_unregister" },
};

MODULE_INFO(depends, "xpp,dahdi");


MODULE_INFO(srcversion, "6DAC749FD0D089C95C56E30");
MODULE_INFO(rhelversion, "9.2");

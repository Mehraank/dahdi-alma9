#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x16f56967, "param_ops_uint" },
	{ 0xdf0256ec, "single_release" },
	{ 0x42cd7ed2, "seq_lseek" },
	{ 0xa35a9cc0, "seq_read" },
	{ 0x7f749536, "usb_deregister" },
	{ 0xd883fead, "usb_register_driver" },
	{ 0x363fb6b9, "kmem_cache_create" },
	{ 0xc8d72a72, "xbus_connect" },
	{ 0xaa101e4c, "proc_create_data" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xe109644e, "xbus_new" },
	{ 0xf76a1db2, "usb_register_dev" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0xd2082e13, "usb_reset_device" },
	{ 0xd63774a1, "xbus_receive_xframe" },
	{ 0xf87a51c2, "get_xframe" },
	{ 0x1adf9cf4, "kmem_cache_destroy" },
	{ 0x1eb6820d, "dump_xframe" },
	{ 0x73c0a7da, "put_xframe" },
	{ 0x919626e2, "usb_submit_urb" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x7cf4682d, "xframe_init" },
	{ 0xf32538f9, "usb_alloc_coherent" },
	{ 0x9ccb08cc, "usb_init_urb" },
	{ 0xa28c0ee, "kmem_cache_alloc" },
	{ 0xb67590b, "kmem_cache_free" },
	{ 0x7f430c3f, "usb_free_coherent" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xf5f7945b, "seq_printf" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x33267c2e, "single_open" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x37a0cba, "kfree" },
	{ 0xcf2a6966, "up" },
	{ 0x181da865, "usb_deregister_dev" },
	{ 0x6626afca, "down" },
	{ 0x39987c01, "xbus_disconnect" },
	{ 0x83ba136e, "remove_proc_entry" },
	{ 0xd5d589c6, "xbus_num" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x3820f61c, "usb_altnum_to_altsetting" },
	{ 0x92997ed8, "_printk" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "xpp");

MODULE_ALIAS("usb:vE4E4p1132d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1142d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1152d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1162d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "0266CBE8600E07D3166F627");
MODULE_INFO(rhelversion, "9.2");

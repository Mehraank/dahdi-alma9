#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x8a9fa9df, "device_remove_file" },
	{ 0xf9a482f9, "msleep" },
	{ 0x9af5c851, "dahdi_rbsbits" },
	{ 0xb64274b3, "xpd_driver_register" },
	{ 0xe3d99689, "xproto_unregister" },
	{ 0x349cba85, "strchr" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x29deac87, "send_cmd_frame" },
	{ 0xd39edbb0, "xpp_span_assigned" },
	{ 0xc3b63d8, "pcmtx_chan" },
	{ 0x56749213, "xpp_maint" },
	{ 0x97438c62, "dump_packet" },
	{ 0x949b7a33, "report_bad_ioctl" },
	{ 0x5af135ef, "xpd_byaddr" },
	{ 0xf87a51c2, "get_xframe" },
	{ 0x478660a1, "xpp_echocan_name" },
	{ 0xd373439f, "xpp_ioctl" },
	{ 0x5811f96d, "notify_bad_xpd" },
	{ 0x1ac5d3cb, "strcspn" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xf45d9bc, "xpp_open" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x7bdead8, "phonedev_alloc_channels" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x4c29be43, "dahdi_spantype2str" },
	{ 0x7e4d5b85, "dahdi_init_span" },
	{ 0xa5d3660e, "xpp_echocan_create" },
	{ 0xa47597fb, "mark_offhook" },
	{ 0xd4a2e742, "xproto_card_entry" },
	{ 0xc37c7a0a, "xproto_register" },
	{ 0x2ef28734, "pcmtx" },
	{ 0x1c9f88fd, "device_create_file" },
	{ 0xeed10554, "update_wanted_pcm_mask" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x2255eaa6, "xpp_close" },
	{ 0x96b29254, "strncasecmp" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x849c3290, "dahdi_sync_tick" },
	{ 0xb2cc48ff, "elect_syncer" },
	{ 0x5034165d, "xpd_alloc" },
	{ 0x64a6fdeb, "alarm2str" },
	{ 0x59a682be, "dahdi_alarm_notify" },
	{ 0x639c8be4, "xpd_set_spanname" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xda23ed38, "xpp_register_request" },
	{ 0x16f56967, "param_ops_uint" },
	{ 0x77634e4b, "xpd_driver_unregister" },
	{ 0x752d18f6, "xframe_next_packet" },
};

MODULE_INFO(depends, "dahdi,xpp");


MODULE_INFO(srcversion, "0EEF360573A6DEEEE1F27EB");
MODULE_INFO(rhelversion, "9.2");

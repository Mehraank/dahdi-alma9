#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x8dd62940, "update_xpd_status" },
	{ 0xb64274b3, "xpd_driver_register" },
	{ 0xe3d99689, "xproto_unregister" },
	{ 0x33267c2e, "single_open" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x29deac87, "send_cmd_frame" },
	{ 0xd39edbb0, "xpp_span_assigned" },
	{ 0xc3b63d8, "pcmtx_chan" },
	{ 0x56749213, "xpp_maint" },
	{ 0xdf0256ec, "single_release" },
	{ 0x949b7a33, "report_bad_ioctl" },
	{ 0x5af135ef, "xpd_byaddr" },
	{ 0xa94932e, "xpp_hooksig" },
	{ 0xf87a51c2, "get_xframe" },
	{ 0xf5f7945b, "seq_printf" },
	{ 0x478660a1, "xpp_echocan_name" },
	{ 0xc615a5f, "dahdi_hdlc_finish" },
	{ 0x73c0a7da, "put_xframe" },
	{ 0x83ba136e, "remove_proc_entry" },
	{ 0xd373439f, "xpp_ioctl" },
	{ 0x62878f47, "param_ops_bool" },
	{ 0x5811f96d, "notify_bad_xpd" },
	{ 0xa35a9cc0, "seq_read" },
	{ 0xf45d9bc, "xpp_open" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x4a3f84c3, "dahdi_hdlc_abort" },
	{ 0xa5d3660e, "xpp_echocan_create" },
	{ 0xa47597fb, "mark_offhook" },
	{ 0xd4a2e742, "xproto_card_entry" },
	{ 0xc37c7a0a, "xproto_register" },
	{ 0x2ef28734, "pcmtx" },
	{ 0xeed10554, "update_wanted_pcm_mask" },
	{ 0x14547b49, "xpd_free" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x2255eaa6, "xpp_close" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x1eb6820d, "dump_xframe" },
	{ 0x849c3290, "dahdi_sync_tick" },
	{ 0xaa101e4c, "proc_create_data" },
	{ 0xb2cc48ff, "elect_syncer" },
	{ 0x42cd7ed2, "seq_lseek" },
	{ 0x5034165d, "xpd_alloc" },
	{ 0x7c836b31, "dahdi_hdlc_getbuf" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xdb386b5, "dahdi_hdlc_putbuf" },
	{ 0xda23ed38, "xpp_register_request" },
	{ 0x16f56967, "param_ops_uint" },
	{ 0x77634e4b, "xpd_driver_unregister" },
	{ 0x752d18f6, "xframe_next_packet" },
};

MODULE_INFO(depends, "xpp,dahdi");


MODULE_INFO(srcversion, "FEAAD1BCB66F5A4FA689C99");
MODULE_INFO(rhelversion, "9.2");

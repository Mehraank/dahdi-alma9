#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0xb64274b3, "xpd_driver_register" },
	{ 0xe3d99689, "xproto_unregister" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x29deac87, "send_cmd_frame" },
	{ 0x5af135ef, "xpd_byaddr" },
	{ 0xf87a51c2, "get_xframe" },
	{ 0x5811f96d, "notify_bad_xpd" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xd4a2e742, "xproto_card_entry" },
	{ 0xc37c7a0a, "xproto_register" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x5034165d, "xpd_alloc" },
	{ 0x77634e4b, "xpd_driver_unregister" },
	{ 0x752d18f6, "xframe_next_packet" },
};

MODULE_INFO(depends, "xpp");


MODULE_INFO(srcversion, "1E931F16E0AC37F7F4D5C04");
MODULE_INFO(rhelversion, "9.2");

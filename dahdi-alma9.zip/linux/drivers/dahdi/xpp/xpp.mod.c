#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x3a236922, "bus_register" },
	{ 0xa24f23d8, "__request_module" },
	{ 0xcf72f966, "module_refcount" },
	{ 0x8a9fa9df, "device_remove_file" },
	{ 0x65b711df, "_dahdi_transmit" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0x88eae55e, "driver_register" },
	{ 0xf90a1e85, "__x86_indirect_thunk_r8" },
	{ 0x7dc85898, "dahdi_free_device" },
	{ 0x349cba85, "strchr" },
	{ 0x33267c2e, "single_open" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0xcdb8f0b1, "del_timer" },
	{ 0x754d539c, "strlen" },
	{ 0xdf0256ec, "single_release" },
	{ 0x352f639e, "kobject_uevent" },
	{ 0x20000329, "simple_strtoul" },
	{ 0xf5f7945b, "seq_printf" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x83ba136e, "remove_proc_entry" },
	{ 0x65d8edc0, "dahdi_get_auto_assign_spans" },
	{ 0x4cfe37ba, "__dahdi_ec_chunk" },
	{ 0x62878f47, "param_ops_bool" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x85df9b6c, "strsep" },
	{ 0x7a2af7b4, "cpu_number" },
	{ 0x1ac5d3cb, "strcspn" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xa35a9cc0, "seq_read" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xaa44a707, "cpumask_next" },
	{ 0xfb384d37, "kasprintf" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x34163751, "param_ops_charp" },
	{ 0xcd3c7696, "del_timer_sync" },
	{ 0xfb578fc5, "memset" },
	{ 0x591c81b7, "proc_mkdir" },
	{ 0x79b1e92f, "device_register" },
	{ 0x11089ac7, "_ctype" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xcb6a6471, "current_task" },
	{ 0x1a58e9f7, "dahdi_register_device" },
	{ 0xe9ffc063, "down_trylock" },
	{ 0x89940875, "mutex_lock_interruptible" },
	{ 0x6460d9de, "dahdi_unregister_device" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x5a5a2271, "__cpu_online_mask" },
	{ 0xec006ff7, "driver_unregister" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0x5a921311, "strncmp" },
	{ 0x3c9cd967, "dahdi_hooksig" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x3dcc0ee2, "dahdi_qevent_lock" },
	{ 0x6626afca, "down" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0xa7eedcc4, "call_usermodehelper" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x3917833f, "dahdi_create_device" },
	{ 0xebb6085b, "sysfs_remove_link" },
	{ 0xe65d95f4, "bus_unregister" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x43f5d304, "_dahdi_receive" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x1c9f88fd, "device_create_file" },
	{ 0xd37f34f1, "sysfs_create_link" },
	{ 0x18c20ba4, "module_put" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x1000e51, "schedule" },
	{ 0xb8b9f817, "kmalloc_order_trace" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xaa101e4c, "proc_create_data" },
	{ 0x42cd7ed2, "seq_lseek" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0xcf2a6966, "up" },
	{ 0x59a682be, "dahdi_alarm_notify" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x79e8b2e1, "device_unregister" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xf21794b6, "dev_set_name" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x16f56967, "param_ops_uint" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x17d0ba17, "try_module_get" },
	{ 0x9c6febfc, "add_uevent_var" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "5035635C7BB6B07F05EEC47");
MODULE_INFO(rhelversion, "9.2");

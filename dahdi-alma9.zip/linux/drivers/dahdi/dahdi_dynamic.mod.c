#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0xa24f23d8, "__request_module" },
	{ 0x65b711df, "_dahdi_transmit" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x9af5c851, "dahdi_rbsbits" },
	{ 0x7dc85898, "dahdi_free_device" },
	{ 0x350f6ce5, "tasklet_unlock_wait" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0xcdb8f0b1, "del_timer" },
	{ 0x3e3bad0a, "__tasklet_hi_schedule" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xcd3c7696, "del_timer_sync" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x1a58e9f7, "dahdi_register_device" },
	{ 0x6460d9de, "dahdi_unregister_device" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x3917833f, "dahdi_create_device" },
	{ 0x2469810f, "__rcu_read_unlock" },
	{ 0x6091797f, "synchronize_rcu" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x43f5d304, "_dahdi_receive" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x18c20ba4, "module_put" },
	{ 0xa916b694, "strnlen" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0x59a682be, "dahdi_alarm_notify" },
	{ 0x71afbda5, "_dahdi_ec_span" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xf21794b6, "dev_set_name" },
	{ 0x8d522714, "__rcu_read_lock" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xf9518d83, "dahdi_set_dynamic_ops" },
	{ 0x17d0ba17, "try_module_get" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "77DB339914BB9A3B056E2E2");
MODULE_INFO(rhelversion, "9.2");

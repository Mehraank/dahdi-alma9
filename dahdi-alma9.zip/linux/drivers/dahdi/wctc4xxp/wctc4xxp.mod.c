#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x1adf9cf4, "kmem_cache_destroy" },
	{ 0x85bd1608, "__request_region" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x2ad56b8b, "dahdi_transcoder_unregister" },
	{ 0x8d2c8c79, "napi_disable" },
	{ 0x77358855, "iomem_resource" },
	{ 0x754d539c, "strlen" },
	{ 0x4d6f6dac, "pci_read_config_byte" },
	{ 0xa7f2819f, "napi_schedule_prep" },
	{ 0x7d330097, "dma_set_mask" },
	{ 0x56470118, "__warn_printk" },
	{ 0x1b5ec3a0, "__dev_kfree_skb_any" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x1246105b, "dma_free_attrs" },
	{ 0x4629334c, "__preempt_count" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x6d16c104, "mutex_lock_killable" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x25974000, "wait_for_completion" },
	{ 0x34163751, "param_ops_charp" },
	{ 0x13edb133, "pci_set_master" },
	{ 0xcd3c7696, "del_timer_sync" },
	{ 0x97d65876, "_dev_warn" },
	{ 0xfb578fc5, "memset" },
	{ 0xf200ff65, "pci_iounmap" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xcb6a6471, "current_task" },
	{ 0xa8ea9fe1, "dahdi_transcoder_register" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xfef216eb, "_raw_spin_trylock" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0xa7be45fa, "free_netdev" },
	{ 0x80c87495, "register_netdev" },
	{ 0xbbc8a5f7, "napi_enable" },
	{ 0x5df1f3bd, "dma_alloc_attrs" },
	{ 0xb67590b, "kmem_cache_free" },
	{ 0xe0272619, "kfree_skb_reason" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x32a096d4, "_dev_err" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0xb420cfbd, "pci_set_mwi" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0xe4fb6171, "dahdi_transcoder_alert" },
	{ 0xb066c88a, "skb_queue_tail" },
	{ 0x79d9fc01, "_dev_info" },
	{ 0xa28c0ee, "kmem_cache_alloc" },
	{ 0x69a0b11c, "__alloc_skb" },
	{ 0x1528edf2, "__napi_schedule" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x1000e51, "schedule" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0xd70aa7fa, "alloc_netdev_mqs" },
	{ 0x10dd36cf, "dma_map_page_attrs" },
	{ 0xbee9114c, "eth_type_trans" },
	{ 0xcdb434b2, "dev_driver_string" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xa86d7fb5, "dahdi_transcoder_alloc" },
	{ 0x1035c7c2, "__release_region" },
	{ 0x43e4e938, "pci_unregister_driver" },
	{ 0x33be7bec, "ether_setup" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x363fb6b9, "kmem_cache_create" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0x87c74d59, "pci_clear_mwi" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0x7b9ff95f, "dahdi_transcoder_free" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x1a16c6ec, "__pci_register_driver" },
	{ 0x64773b08, "request_firmware" },
	{ 0xbeeaf684, "dma_unmap_page_attrs" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x882ee7f1, "skb_dequeue" },
	{ 0xa1566d53, "unregister_netdev" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0xa6257a2f, "complete" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xefaff65f, "netif_napi_add_weight" },
	{ 0x9a5ca076, "pci_iomap" },
	{ 0xd09827c9, "skb_put" },
	{ 0xffd0ea69, "pci_enable_device" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xfa033d18, "skb_copy_bits" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xc31db0ce, "is_vmalloc_addr" },
	{ 0xc1514a3b, "free_irq" },
};

MODULE_INFO(depends, "dahdi_transcode");

MODULE_ALIAS("pci:v0000D161d00003400sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008004sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "CA182FBE73809093F0090CA");
MODULE_INFO(rhelversion, "9.2");

#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0xacafbcb4, "skb_queue_purge" },
	{ 0xb5e84b77, "dev_remove_pack" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0xb66b52b, "dahdi_dynamic_unregister_driver" },
	{ 0x160f1369, "dahdi_dynamic_register_driver" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0x3f42594a, "dev_add_pack" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xe6586838, "dev_get_by_name" },
	{ 0x28bbb0e9, "init_net" },
	{ 0xa916b694, "strnlen" },
	{ 0x349cba85, "strchr" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0x754d539c, "strlen" },
	{ 0x7c8af009, "__pskb_pull_tail" },
	{ 0xe0272619, "kfree_skb_reason" },
	{ 0x95f4b173, "dahdi_dynamic_receive" },
	{ 0x9fbff1b3, "skb_pull" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0xb066c88a, "skb_queue_tail" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x38aa1380, "skb_push" },
	{ 0x69acdf38, "memcpy" },
	{ 0xd09827c9, "skb_put" },
	{ 0xb048d907, "__netdev_alloc_skb" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x37a0cba, "kfree" },
	{ 0x92997ed8, "_printk" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x882ee7f1, "skb_dequeue" },
	{ 0x9e189b07, "dev_queue_xmit" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "dahdi_dynamic");


MODULE_INFO(srcversion, "F86E686D35FB44D42790D97");
MODULE_INFO(rhelversion, "9.2");

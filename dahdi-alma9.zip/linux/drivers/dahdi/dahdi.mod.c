#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3af7223e, "module_layout" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x3a236922, "bus_register" },
	{ 0xa24f23d8, "__request_module" },
	{ 0x72fd0e67, "cdev_del" },
	{ 0x4ce572de, "kmalloc_caches" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x21c74aa9, "cdev_init" },
	{ 0xf9a482f9, "msleep" },
	{ 0x88eae55e, "driver_register" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x33267c2e, "single_open" },
	{ 0x5567c34d, "param_ops_int" },
	{ 0x754d539c, "strlen" },
	{ 0xad73041f, "autoremove_wake_function" },
	{ 0xd20fef74, "dev_printk" },
	{ 0xdf0256ec, "single_release" },
	{ 0x352f639e, "kobject_uevent" },
	{ 0xf5f7945b, "seq_printf" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x83ba136e, "remove_proc_entry" },
	{ 0x4f82f011, "device_destroy" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x2a4094da, "__register_chrdev" },
	{ 0x66cca4f9, "__x86_indirect_thunk_rcx" },
	{ 0x7f03b6a9, "crc_ccitt_table" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0xad2ea79a, "_dev_notice" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xa35a9cc0, "seq_read" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xb0cd8620, "proc_remove" },
	{ 0xfb384d37, "kasprintf" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x34163751, "param_ops_charp" },
	{ 0xcd3c7696, "del_timer_sync" },
	{ 0xfb578fc5, "memset" },
	{ 0x1e1e140e, "ns_to_timespec64" },
	{ 0x591c81b7, "proc_mkdir" },
	{ 0x5a2dd1e4, "device_del" },
	{ 0x79b1e92f, "device_register" },
	{ 0x11089ac7, "_ctype" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xcb6a6471, "current_task" },
	{ 0x2e2b40d2, "strncat" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x449ad0a7, "memcmp" },
	{ 0xec006ff7, "driver_unregister" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x16226264, "device_create" },
	{ 0x3cf85989, "mod_timer" },
	{ 0xebb6085b, "sysfs_remove_link" },
	{ 0xbef4436a, "device_add" },
	{ 0x32a096d4, "_dev_err" },
	{ 0xe65d95f4, "bus_unregister" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0xa58f562a, "cdev_add" },
	{ 0xd37f34f1, "sysfs_create_link" },
	{ 0x18c20ba4, "module_put" },
	{ 0x79d9fc01, "_dev_info" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0xa916b694, "strnlen" },
	{ 0x7682ba4e, "__copy_overflow" },
	{ 0x54aa5948, "put_device" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x1000e51, "schedule" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x8b4cd20d, "kmem_cache_alloc_trace" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x79e73c6a, "get_device" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xaa101e4c, "proc_create_data" },
	{ 0x42cd7ed2, "seq_lseek" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0xd5fd90f1, "prepare_to_wait" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x33d44b2a, "device_initialize" },
	{ 0x92c6c509, "class_destroy" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x79e8b2e1, "device_unregister" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xb0e602eb, "memmove" },
	{ 0xf21794b6, "dev_set_name" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x36c14a3, "__class_create" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0x17d0ba17, "try_module_get" },
	{ 0xe914e41e, "strcpy" },
	{ 0x9c6febfc, "add_uevent_var" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "6A456DB4FE6525F7D516452");
MODULE_INFO(rhelversion, "9.2");

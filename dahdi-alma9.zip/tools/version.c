/*
 * version.c.in
 */

const char dahdi_tools_version[] = "DAHDI Tools Version - 3.2.0";

